package com.example.gasstationsmartcontrol.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.support.v4.app.Fragment
import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProvider
import android.util.Log
import android.widget.Button
import com.example.gasstationsmartcontrol.R
import com.example.gasstationsmartcontrol.databinding.FragmentHomeBinding
import com.amazonaws.services.iot.client.AWSIotMqttClient



class HomeFragment : Fragment() {

    private lateinit var homeViewModel: HomeViewModel
    private var _binding: FragmentHomeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        homeViewModel =
            ViewModelProvider(
                this,
                ViewModelProvider.NewInstanceFactory()
            ).get(HomeViewModel::class.java)

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textHome
        homeViewModel.text.observe(viewLifecycleOwner, Observer {
            textView.text = it
        })

        val clientEndpoint = "a3ehaer69y3v5p-ats.iot.eu-west-1.amazonaws.com" // use value returned by describe-endpoint --endpoint-type "iot:Data-ATS"
        val clientId = "mobile-franciscojavier" // replace with your own client ID. Use unique client IDs for concurrent connections.
        val certificateFile = assets.open("certificate.pem.crt") // X.509 based certificate file
        val privateKeyFile = assets.open("private.pem.key") // PKCS#1 or PKCS#8 PEM encoded private key file
        val pair: KeyStorePasswordPair = SampleUtil.getKeyStorePasswordPair(certificateFile, privateKeyFile)
        val client = AWSIotMqttClient(clientEndpoint, clientId, pair.keyStore, pair.keyPassword)

        client.connect()


        var button1 = root.findViewById<Button>(R.id.button)
        button1.setOnClickListener {
            val unixTime = System.currentTimeMillis() / 1000L
            val json = "{ \"payload\": { \"deviceid\": \""+client.clientId+"\", \"timestamp\": "+unixTime+",  \"location\": { \"lat\": "+location.latitude+", \"long\": "+location.longitude+" } } }";
            Log.e("json:", json)
            val message = AWSIotMessage("iot/trackers/"+client.clientId, AWSIotQos.QOS0, json.toByteArray())
            try {
                client.publish(message)
            } catch (e: AWSIotException) {
                println(System.currentTimeMillis().toString() + ": publish failed for " + json)
            }
        }

        var button2 = root.findViewById<Button>(R.id.button2)
        button2.setOnClickListener {
            val unixTime = System.currentTimeMillis() / 1000L
            val json = "{ \"payload\": { \"deviceid\": \""+client.clientId+"\", \"timestamp\": "+unixTime+",  \"location\": { \"lat\": "+location.latitude+", \"long\": "+location.longitude+" } } }";
            Log.e("json:", json)
            val message = AWSIotMessage("iot/trackers/"+client.clientId, AWSIotQos.QOS0, json.toByteArray())
            try {
                client.publish(message)
            } catch (e: AWSIotException) {
                println(System.currentTimeMillis().toString() + ": publish failed for " + json)
            }
        }
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}